package com.example.leticoursework.client.gui.concerts;

import com.example.leticoursework.server.entity.Concerts;

import javax.swing.*;

public class ConcertsList extends JList<Concerts> {
    public ConcertsList(){ //Создание списка и создание представления обьектов в списке
        super(new ConcertsModelGui<>());
        setCellRenderer(new ConcertsRenderer());
    }
    public ConcertsModelGui getConcertsModel(){
        return (ConcertsModelGui) getModel();
    }
}
