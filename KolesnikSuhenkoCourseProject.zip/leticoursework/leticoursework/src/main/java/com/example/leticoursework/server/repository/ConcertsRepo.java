package com.example.leticoursework.server.repository;

import com.example.leticoursework.server.entity.Concerts;
import org.springframework.data.repository.CrudRepository;

public interface ConcertsRepo extends CrudRepository<Concerts, Long> {
}
