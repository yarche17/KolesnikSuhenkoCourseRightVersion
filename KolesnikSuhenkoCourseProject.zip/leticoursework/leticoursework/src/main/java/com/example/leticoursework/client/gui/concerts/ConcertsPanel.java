package com.example.leticoursework.client.gui.concerts;

import com.example.leticoursework.client.gui.ColoriesStyle;
import javax.swing.*;
import java.awt.*;

public class ConcertsPanel extends JPanel {
    public ConcertsPanel(){
        ColoriesStyle coloriesStyle = new ColoriesStyle();

        ConcertsList list = new ConcertsList();
        list.setBackground(coloriesStyle.background1);


        JTextField addressField = new JTextField(12); //Строки ввода текста
        addressField.setFont(coloriesStyle.fontMain); addressField.setBackground(coloriesStyle.textBackground); addressField.setForeground(Color.white);
        JTextField countryField = new JTextField(12); //Строки ввода текста
        countryField.setFont(coloriesStyle.fontMain); countryField.setBackground(coloriesStyle.textBackground); countryField.setForeground(Color.white);
        JTextField cityField = new JTextField(12);
        cityField.setFont(coloriesStyle.fontMain); cityField.setBackground(coloriesStyle.textBackground); cityField.setForeground(Color.white);
        JTextField dateField = new JTextField(8);
        dateField.setFont(coloriesStyle.fontMain); dateField.setBackground(coloriesStyle.textBackground); dateField.setForeground(Color.white);
        JTextField timeField = new JTextField(8);
        timeField.setFont(coloriesStyle.fontMain); timeField.setBackground(coloriesStyle.textBackground); timeField.setForeground(Color.white);

        JLabel addressLabel = new JLabel("Address:"); //Текст
        addressLabel.setFont(coloriesStyle.fontHead); addressLabel.setForeground(coloriesStyle.text);
        JLabel countryLabel = new JLabel("Country:"); //Текст
        countryLabel.setFont(coloriesStyle.fontHead); countryLabel.setForeground(coloriesStyle.text);
        JLabel cityLabel = new JLabel("City:");
        cityLabel.setFont(coloriesStyle.fontHead); cityLabel.setForeground(coloriesStyle.text);
        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setFont(coloriesStyle.fontHead); dateLabel.setForeground(coloriesStyle.text);
        JLabel timeLabel = new JLabel("Time:");
        timeLabel.setFont(coloriesStyle.fontHead); timeLabel.setForeground(coloriesStyle.text);


        JButton addButton = new JButton("ADD");
        addButton.setOpaque(true);
        addButton.setBackground(Color.black); addButton.setForeground(Color.white); addButton.setFont(coloriesStyle.fontHead);
        JButton delButton = new JButton("DELETE");
        delButton.setOpaque(true);
        delButton.setBackground(Color.black); delButton.setForeground(Color.white); delButton.setFont(coloriesStyle.fontHead);
        JButton editButton = new JButton("EDIT");
        editButton.setOpaque(true);
        editButton.setBackground(Color.black); editButton.setForeground(Color.white); editButton.setFont(coloriesStyle.fontHead);

/*        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Team team = new Team();
                model.addTeam(team);
                list.
            }
        });
*/






        JToolBar toolBar = new JToolBar(); //Создание тулбара и добавление на него кнопок
        toolBar.setFloatable(false);
        toolBar.setBackground(coloriesStyle.background1);
        toolBar.add(addButton);
        toolBar.add(delButton);
        toolBar.add(editButton);

        JPanel addressPanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); // Отдельные панели для каждого элемента
        addressPanel.setBackground(coloriesStyle.background);
        addressPanel.add(addressLabel);
        addressPanel.add(addressField);

        JPanel countryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); // Отдельные панели для каждого элемента
        countryPanel.setBackground(coloriesStyle.background);
        countryPanel.add(countryLabel);
        countryPanel.add(countryField);

        JPanel cityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        cityPanel.setBackground(coloriesStyle.background);
        cityPanel.add(cityLabel);
        cityPanel.add(cityField);

        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        datePanel.setBackground(coloriesStyle.background);
        datePanel.add(dateLabel);
        datePanel.add(dateField);

        JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        timePanel.setBackground(coloriesStyle.background);
        timePanel.add(timeLabel);
        timePanel.add(timeField);


        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(list, BorderLayout.CENTER);
        topPanel.add(toolBar, BorderLayout.SOUTH);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(coloriesStyle.background);
        bottomPanel.setLayout(new GridLayout(3,2));
        bottomPanel.add(addressPanel);
        bottomPanel.add(countryPanel);
        bottomPanel.add(datePanel);
        bottomPanel.add(cityPanel);
        bottomPanel.add(timePanel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topPanel, bottomPanel);
        splitPane.setDividerLocation(430);


        setLayout(new BorderLayout());
        add(splitPane, BorderLayout.CENTER);
    }
}

