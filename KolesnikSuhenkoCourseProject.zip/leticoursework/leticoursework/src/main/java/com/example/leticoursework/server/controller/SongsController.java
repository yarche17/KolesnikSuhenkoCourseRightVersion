package com.example.leticoursework.server.controller;

import com.example.leticoursework.server.entity.Songs;
import com.example.leticoursework.server.service.SongsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/songs")
public class SongsController {
    @Autowired
    private SongsService songsService;


    @PostMapping
    public ResponseEntity addSongs(@RequestBody Songs songs, @RequestParam Long musicianId){
        try {
            return ResponseEntity.ok(songsService.addSongs(songs, musicianId));
        }catch (Exception e){
            return ResponseEntity.badRequest().body("Произошла ошибка!");
        }
    }

    @GetMapping
    public ResponseEntity getSongs(@RequestParam Long id){
        try {
            return ResponseEntity.ok(songsService.getSongs(id));
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка!");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity delSongs(@PathVariable Long id){
        try {
            return ResponseEntity.ok(songsService.delSongs(id));

        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity editSongs(@RequestBody Songs songs, @PathVariable Long id){
        try {
            songsService.editSongs(id, songs);
            return ResponseEntity.ok("Пользователь был успешно изменен!");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }
}
