package com.example.leticoursework.client.gui;

import com.example.leticoursework.client.gui.concerts.ConcertsPanel;
import com.example.leticoursework.client.gui.musician.MusicianPanel;
import com.example.leticoursework.client.gui.songs.SongsPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {

    public MainFrame() throws HeadlessException {
        super("Music base V.");


        JMenuBar menuBar = new JMenuBar();
        JMenu menuFile = new JMenu("File");
        menuBar.add(menuFile);
        JMenuItem itemFullScreen = new JMenuItem("Full Screen");
        JMenuItem itemMinimize = new JMenuItem("Minimize");
        JMenuItem itemExit = new JMenuItem("Exit");
        menuFile.add(itemFullScreen); menuFile.add(itemMinimize); menuFile.addSeparator(); menuFile.add(itemExit);

        itemFullScreen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setExtendedState(JFrame.MAXIMIZED_BOTH);
            }
        });

        itemMinimize.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setExtendedState(JFrame.ICONIFIED);
            }
        });

        itemExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });


        getContentPane().setBackground(new Color(18,18,18));
        UIManager.put("TabbedPane.selected", new Color(86,179,95));
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(new Color(18,18,18)); tabbedPane.setForeground(new Color(255,255,255));
        tabbedPane.setFont(new Font("Segoe UI Black", Font.PLAIN, 15));
        tabbedPane.addTab("Musician", new MusicianPanel());
        tabbedPane.addTab("Songs", new SongsPanel());
        tabbedPane.addTab("Concerts", new ConcertsPanel());


        setLayout(new BorderLayout());
        add(tabbedPane, BorderLayout.CENTER);
        add(menuBar, BorderLayout.NORTH);
    }
}
