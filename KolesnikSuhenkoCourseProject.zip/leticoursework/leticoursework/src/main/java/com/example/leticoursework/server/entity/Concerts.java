package com.example.leticoursework.server.entity;

import jakarta.persistence.*;

@Entity
public class Concerts {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String address;
    private String country;
    private String city;
    private String date;
    private String time;

    @ManyToOne
    @JoinColumn(name = "musician_id")
    private Musician musicianN;

    public Concerts(){
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Musician getMusicianN() {
        return musicianN;
    }

    public void setMusicianN(Musician musicianN) {
        this.musicianN = musicianN;
    }
}
