package com.example.leticoursework.client.gui.songs;


import com.example.leticoursework.server.entity.Songs;
import javax.swing.*;

public class SongsList extends JList<Songs> {
    public SongsList(){ //Создание списка и создание представления обьектов в списке
        super(new SongsModelGui<>());
        setCellRenderer(new SongsRenderer());
    }
    public SongsModelGui getMusicianModel(){
        return (SongsModelGui) getModel();
    }
}

