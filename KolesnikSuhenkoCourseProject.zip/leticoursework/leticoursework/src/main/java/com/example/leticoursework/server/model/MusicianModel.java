package com.example.leticoursework.server.model;

import com.example.leticoursework.server.entity.Musician;

public class MusicianModel {
    private Long id;
    private String name;
    private String fio;
    private String country;

    public static MusicianModel toModel(Musician musician){
        MusicianModel model = new MusicianModel();
        model.setId(musician.getId());
        model.setFio(musician.getFio());
        model.setCountry(model.getCountry());
        return model;
    }

    public MusicianModel(){
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

       public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
