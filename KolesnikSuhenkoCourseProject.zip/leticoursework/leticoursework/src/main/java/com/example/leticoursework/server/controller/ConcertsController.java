package com.example.leticoursework.server.controller;

import com.example.leticoursework.server.entity.Concerts;
import com.example.leticoursework.server.service.ConcertsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/concerts")
public class ConcertsController {

    @Autowired
    private ConcertsService concertsService;


    @PostMapping
    public ResponseEntity addConcerts(@RequestBody Concerts concerts, @RequestParam Long musicianId){
        try {
            return ResponseEntity.ok(concertsService.addConcerts(concerts, musicianId));
        }catch (Exception e){
            return ResponseEntity.badRequest().body("Произошла ошибка!");
        }
    }

    @GetMapping
    public ResponseEntity getConcerts(@RequestParam Long id){
        try {
            return ResponseEntity.ok(concertsService.getConcerts(id));
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка!");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity delConcerts(@PathVariable Long id){
        try {
            return ResponseEntity.ok(concertsService.delConcerts(id));

        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity editConcerts(@RequestBody Concerts concerts, @PathVariable Long id){
        try {
            concertsService.editConcerts(id, concerts);
            return ResponseEntity.ok("Пользователь был успешно изменен!");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }
}
