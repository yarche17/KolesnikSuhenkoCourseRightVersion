package com.example.leticoursework.server.controller;

import com.example.leticoursework.server.entity.Musician;
import com.example.leticoursework.server.service.MusicianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/musician")
public class MusicianController {

    @Autowired
    private MusicianService musicianService;


    @PostMapping
    public ResponseEntity addMusician(@RequestBody Musician musician){
        try {
            musicianService.addMusician(musician);
            return ResponseEntity.ok("Пользователь был успешно сохранен");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка!");
        }
    }



    @GetMapping
    public ResponseEntity getMusician(@RequestParam Long id){
        try {
            return ResponseEntity.ok(musicianService.getMusician(id));
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка!");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity delMusician(@PathVariable Long id){
        try {
            return ResponseEntity.ok(musicianService.delMusician(id));
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }


    @PatchMapping("/{id}")
    public ResponseEntity editMusician(@RequestBody Musician musician, @PathVariable Long id){
        try {
            musicianService.editMusician(id, musician);
            return ResponseEntity.ok("Пользователь был успешно изменен!");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }

}
