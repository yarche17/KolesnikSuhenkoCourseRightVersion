package com.example.leticoursework.server.repository;


import com.example.leticoursework.server.entity.Songs;
import org.springframework.data.repository.CrudRepository;

public interface SongsRepo extends CrudRepository<Songs, Long> {
}
