package com.example.leticoursework.client.gui.songs;

import com.example.leticoursework.client.gui.ColoriesStyle;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class SongsPanel extends JPanel {
    public SongsPanel(){
        ColoriesStyle coloriesStyle = new ColoriesStyle();


        SongsList list = new SongsList();
        list.setBackground(coloriesStyle.background1);


        JTextField nameField = new JTextField(15);
        nameField.setFont(coloriesStyle.fontMain); nameField.setBackground(coloriesStyle.textBackground); nameField.setForeground(Color.white);
        JTextField genreField = new JTextField(15);
        genreField.setFont(coloriesStyle.fontMain); genreField.setBackground(coloriesStyle.textBackground); genreField.setForeground(Color.white);
        JTextField durationField = new JTextField(7);
        durationField.setFont(coloriesStyle.fontMain); durationField.setBackground(coloriesStyle.textBackground); durationField.setForeground(Color.white);
        JTextArea lyricsArea = new JTextArea(); lyricsArea.setBackground(coloriesStyle.textBackground); lyricsArea.setForeground(Color.white);
        lyricsArea.setFont(coloriesStyle.fontMain);


        JLabel nameLabel = new JLabel("Song Name:");
        nameLabel.setFont(coloriesStyle.fontHead); nameLabel.setForeground(coloriesStyle.text);
        JLabel genreLabel = new JLabel("Genre:");
        genreLabel.setFont(coloriesStyle.fontHead); genreLabel.setForeground(coloriesStyle.text);
        JLabel durationLabel = new JLabel("Duration:");
        durationLabel.setFont(coloriesStyle.fontHead); durationLabel.setForeground(coloriesStyle.text);


        JButton addButton = new JButton("ADD");
        addButton.setOpaque(true);
        addButton.setBackground(Color.black); addButton.setForeground(Color.white); addButton.setFont(coloriesStyle.fontHead);
        JButton delButton = new JButton("DELETE");
        delButton.setOpaque(true);
        delButton.setBackground(Color.black); delButton.setForeground(Color.white); delButton.setFont(coloriesStyle.fontHead);
        JButton editButton = new JButton("EDIT");
        editButton.setOpaque(true);
        editButton.setBackground(Color.black); editButton.setForeground(Color.white); editButton.setFont(coloriesStyle.fontHead);

/*        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Team team = new Team();
                model.addTeam(team);
                list.
            }
        });
*/






        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setBackground(coloriesStyle.background1);
        toolBar.add(addButton);
        toolBar.add(delButton);
        toolBar.add(editButton);


        JPanel namePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        namePanel.setBackground(coloriesStyle.background);
        namePanel.add(nameLabel);
        namePanel.add(nameField);

        JPanel genrePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genrePanel.setBackground(coloriesStyle.background);
        genrePanel.add(genreLabel);
        genrePanel.add(genreField);

        JPanel durationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        durationPanel.setBackground(coloriesStyle.background);
        durationPanel.add(durationLabel);
        durationPanel.add(durationField);

        JPanel lyricsPanel = new JPanel(new BorderLayout());
        lyricsPanel.add(lyricsArea, BorderLayout.CENTER);
        lyricsPanel.setBorder(BorderFactory.createTitledBorder(null, "Lyrics:", TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI Black", Font.BOLD, 15), coloriesStyle.text));
        lyricsPanel.setBackground(coloriesStyle.background);

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.add(list, BorderLayout.CENTER);
        leftPanel.add(toolBar, BorderLayout.SOUTH);


        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.add(namePanel);
        rightPanel.add(genrePanel);
        rightPanel.add(durationPanel);
        rightPanel.add(lyricsPanel);


        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(670);


        setLayout(new BorderLayout());
        add(splitPane, BorderLayout.CENTER);
    }
}
