package com.example.leticoursework.server.service;



import com.example.leticoursework.server.entity.Musician;
import com.example.leticoursework.server.entity.Songs;
import com.example.leticoursework.server.model.SongsModel;
import com.example.leticoursework.server.repository.MusicianRepo;
import com.example.leticoursework.server.repository.SongsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SongsService {
    @Autowired
    private SongsRepo songsRepo;
    @Autowired
    private MusicianRepo musicianRepo;

    public SongsModel addSongs(Songs songs, Long musicianId){
        Musician musician = musicianRepo.findById(musicianId).get();
        songs.setMusicianN(musician);
        return SongsModel.toModel(songsRepo.save(songs));

    }

    public SongsModel getSongs(Long id){
        Songs songs = songsRepo.findById(id).get();
        return SongsModel.toModel(songs);
    }

    public Long delSongs(Long id){
        songsRepo.deleteById(id);
        return id;
    }

    public SongsModel editSongs(Long id, Songs songs) {
        Songs songs1 = songsRepo.findById(id).get();
        songs1.setName(songs.getName());
        songs1.setGenre(songs.getGenre());
        songs1.setDuration(songs.getDuration());
        songs1.setLyrics(songs.getLyrics());
        return SongsModel.toModel(songsRepo.save(songs1));
    }
}